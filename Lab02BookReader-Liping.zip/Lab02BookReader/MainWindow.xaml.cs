﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab02BookReader
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }


        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string username = tbxUsername.Text.ToLower();
            string password = tbxPassword.Password;
            if ((username == "comp306lab02liping" || username == "comp306test01") && (password == "qwertyu"))
            {
                MessageBox.Show("Welcome back " + username + "!"  );

                BookList booklist = new BookList(username);
                booklist.Owner = Window.GetWindow(this);
                this.Hide();
                booklist.ShowDialog();
                this.Close();
            }
            else {
                MessageBox.Show("Please check your credential to login.");               
            }
        }        
    }
}
