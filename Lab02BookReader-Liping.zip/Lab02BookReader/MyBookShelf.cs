﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab02BookReader
{
    class MyBookShelf
    {
        public string bookId { get; set; } //auto generated guid for primary key

        public string username { get; set; }
      
        public string bookTitle { get; set; }
        public String ISBN { get; set; }
        public string author { get; set; }
        public DateTime created { get; set; }
        public DateTime updated { get; set; }
        public string pdfPath { get; set; }
        public int lastViewedPage { get; set; }
               
        } 
    }

