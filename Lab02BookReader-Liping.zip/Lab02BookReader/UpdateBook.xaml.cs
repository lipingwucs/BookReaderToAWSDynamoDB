﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab02BookReader
{
    /// <summary>
    /// Interaction logic for UpdateBook.xaml
    /// </summary>
    public partial class UpdateBook : Window
    {
       

        string tableName = "MyBookShelf";
        string hashKey = "bookId";
        AmazonDynamoDBClient client;
        DynamoDBContext context;
        private string username;
        private string bookId;
        private string bookPath = "d:\\books\\";
        private int lastViewedPage;

        //constructor
        public UpdateBook(string username, string bookId)
        {
            this.username = username;
            this.bookId = bookId;

            InitializeComponent();
            client = new AmazonDynamoDBClient();
            loadBook();
        }

        //load book information from DynamoDB to updata window
        private void loadBook() {
            //Set a local DB context
            context = new DynamoDBContext(client);

            Amazon.DynamoDBv2.DocumentModel.Table MyBookShelfTable = Amazon.DynamoDBv2.DocumentModel.Table.LoadTable(client, tableName);

            GetItemOperationConfig config = new GetItemOperationConfig
            {
                // Return the selected item.
                AttributesToGet = new List<string> { "bookTitle", "ISBN", "author", "pdfPath", "lastViewedPage" },
                ConsistentRead = true
            };
            Document document = MyBookShelfTable.GetItem(bookId, config);
            tbxBookTitle.Text = document["bookTitle"];
            tbxAuthor.Text = document["author"];
            tbxISBN.Text = document["ISBN"];
            tbxPDFPath.Text = document["pdfPath"];
            lastViewedPage = Int32.Parse(document["lastViewedPage"]);
        }

        private void Btn_UpdateBook_Click(object sender, RoutedEventArgs e)
        {
            Amazon.DynamoDBv2.DocumentModel.Table MyBookShelfTable = Amazon.DynamoDBv2.DocumentModel.Table.LoadTable(client, tableName);
            var myBookShelf = new Document();
            myBookShelf["bookId"]  = this.bookId;

            //list of attribute updates
            // the following replaces the existing bookshelf
            myBookShelf["bookTitle"] = tbxBookTitle.Text;
            myBookShelf["ISBN"] = tbxISBN.Text;
            myBookShelf["author"] = tbxAuthor.Text;
            myBookShelf["pdfPath"] = tbxPDFPath.Text;
            myBookShelf["updated"] = DateTime.UtcNow; //updatetime for booklist view update
            myBookShelf["lastViewedPage"] = (lastViewedPage + 10).ToString();  //suppose every update, read 10 pages

            // Optional parameters.
            UpdateItemOperationConfig config = new UpdateItemOperationConfig
            {
                // Get updated item in response.
                ReturnValues = ReturnValues.AllNewAttributes
            };
            Document updatedBookShelf = MyBookShelfTable.UpdateItem(myBookShelf, config);

            MessageBox.Show("Book Record Update Successfully!");
            this.Close(); 
        }

        private void Btn_Clear_Click(object sender, RoutedEventArgs e)
        {
            tbxAuthor.Text = "";
            tbxBookTitle.Text = "";
            tbxISBN.Text = "";
            tbxPDFPath.Text = bookPath;
        }
    }
}
