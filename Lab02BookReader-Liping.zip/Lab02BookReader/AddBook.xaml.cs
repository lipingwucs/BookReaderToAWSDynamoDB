﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab02BookReader
{
    /// <summary>
    /// Interaction logic for AddBook.xaml
    /// </summary>
    public partial class AddBook : Window
    {
        string tableName = "MyBookShelf";
        string hashKey = "bookId";
        AmazonDynamoDBClient client;
        DynamoDBContext context;
        private string username;
        string bookPath = "d:\\books\\";

        public AddBook(String username)
        {
            this.username = username;
            InitializeComponent();
            client = new AmazonDynamoDBClient();
            tbxPDFPath.Text = bookPath;

        }

        private void Btn_AddBook_Click(object sender, RoutedEventArgs e)
        {
            //Set a local DB context
            context = new DynamoDBContext(client);
            MyBookShelf myBook = new MyBookShelf {
                username = this.username,
                bookId = Guid.NewGuid().ToString(),
                bookTitle = tbxBookTitle.Text,
                author = tbxAuthor.Text,
                ISBN = tbxISBN.Text,
                pdfPath = tbxPDFPath.Text,
                lastViewedPage = 0,
                created = DateTime.UtcNow,
                updated = DateTime.UtcNow
            };
            context.Save<MyBookShelf>(myBook);
            MessageBox.Show("Book Record Inserted Successfully!");
            this.Close(); 
        }

        private void Btn_Clear_Click(object sender, RoutedEventArgs e)
        {
            tbxAuthor.Text = "";
            tbxBookTitle.Text = "";
            tbxISBN.Text = "";
            tbxPDFPath.Text = bookPath;
        }
    }
}
