﻿using Amazon;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.Model;
using Amazon.Runtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MessageBox = System.Windows.Forms.MessageBox;

namespace Lab02BookReader
{
    /// <summary>
    /// Interaction logic for BookList.xaml
    /// </summary>
    public partial class BookList : Window
    {
        string tableName = "MyBookShelf";
        string hashKey = "bookId";
        AmazonDynamoDBClient client;
        DynamoDBContext context;
        private string username;
        private string bookId; 

        //constructor
        public BookList(string username )
        {
            this.username = username; //receive the login username to this window           
            InitializeComponent();
            lblWelcome.Content =  "Hello "+  username +"!";
            
            CreateTable();
            InsertSeedData();
            RefreshGrid();
            //dataGridBookList.ItemsSource = LoadCollectionData();
        }

            private void AddBook_Click(object sender, RoutedEventArgs e)
        {
            AddBook addbook = new AddBook(this.username);
            addbook.Owner = Window.GetWindow(this);
            addbook.ShowDialog();
            this.RefreshGrid();
        }      

        private void MyLastViewed_Click(object sender, RoutedEventArgs e)
        {
            MyBookShelf myBookShelf = (MyBookShelf)dataGridBookList.SelectedItem;
            if (myBookShelf == null)
            {
                MessageBox.Show("no selelcted book to view. ");
                return;
            }
            MessageBox.Show("current selected book " + myBookShelf.bookTitle);

            LastViewedBook lastview = new LastViewedBook(this.username);
            lastview.Owner = Window.GetWindow(this);
            lastview.ShowDialog();
        }

        private void RemoveBook_Click(object sender, RoutedEventArgs e)
        {
            MyBookShelf myBookShelf = (MyBookShelf)dataGridBookList.SelectedItem;
            if (myBookShelf == null) {
                MessageBox.Show("no selelcted book to remove. ");
                return;
            }
            MessageBox.Show("current selected book "+ myBookShelf.bookTitle);

       
            MessageBoxResult result = (MessageBoxResult)MessageBox.Show("Are you sure you want to remove the book: " + myBookShelf.bookTitle + "?", 
                "Remove a book", (MessageBoxButtons)MessageBoxButton.YesNoCancel);
                switch (result)
                    {
                        case MessageBoxResult.Yes:
                             //   MessageBox.Show("Hello to you too!", "My App");
                            //Set a local DB context
                            context = new DynamoDBContext(client);
                            //context.Delete(myBookShelf); //another way to delete a row

                            Amazon.DynamoDBv2.DocumentModel.Table MyBookShelfTable = Amazon.DynamoDBv2.DocumentModel.Table.LoadTable(client, tableName);
                            DeleteItemOperationConfig config = new DeleteItemOperationConfig
                            {
                                // Return the deleted item.
                                ReturnValues = ReturnValues.AllOldAttributes
                            };
                            MyBookShelfTable.DeleteItem(myBookShelf.bookId, config);
                            MessageBox.Show(myBookShelf.bookTitle + " removed succeed!");
                            this.RefreshGrid();
                        break;
                        case MessageBoxResult.No:
                       
                            break;
                        case MessageBoxResult.Cancel:                       
                            break;
                    }             
        }


        private void CreateTable()
        {
            client = new AmazonDynamoDBClient();
            var tableResponse = client.ListTables();
            if (!tableResponse.TableNames.Contains(tableName))
            {
                MessageBox.Show("Table not found, creating table => " + tableName);
                client.CreateTable(new CreateTableRequest
                {
                    TableName = tableName,
                    ProvisionedThroughput = new ProvisionedThroughput
                    {
                        ReadCapacityUnits = 3,
                        WriteCapacityUnits = 1
                    },
                    KeySchema = new List<KeySchemaElement>
                    {
                        new KeySchemaElement
                        {
                            AttributeName = hashKey,
                            KeyType = KeyType.HASH
                        }
                    },
                    AttributeDefinitions = new List<AttributeDefinition>
                    {
                        new AttributeDefinition { AttributeName = hashKey, AttributeType=ScalarAttributeType.S }
                    }
                });

                bool isTableAvailable = false;
                while (!isTableAvailable)
                {
                    Console.WriteLine("Waiting for table to be active...");
                    Thread.Sleep(5000);
                    var tableStatus = client.DescribeTable(tableName);
                    isTableAvailable = tableStatus.Table.TableStatus == "ACTIVE";                   
                }
                MessageBox.Show("DynamoDB Table Created Successfully!");
            }
        }


        //add seeddata 
        private List<MyBookShelf> LoadCollectionData()
        {
            List<MyBookShelf> bookShelves = new List<MyBookShelf>();
            bookShelves.Add(new MyBookShelf()
            {
                username = this.username,
                bookId = Guid.NewGuid().ToString(),
                bookTitle = "Java programming",
                author = "liping",
                ISBN = "123456789",
                pdfPath = "java.pdf",
                lastViewedPage = 1,
                created = DateTime.UtcNow,
                updated = DateTime.UtcNow
            });
            bookShelves.Add(new MyBookShelf()
            {
                username = this.username,
                bookId = Guid.NewGuid().ToString(),
                bookTitle = "C# programming",
                author = "liping",
                ISBN = "123456790",
                pdfPath = "csharp.pdf",
                lastViewedPage = 1,
                created = DateTime.UtcNow,
                updated = DateTime.UtcNow
            });
            return bookShelves;
        }

        private void InsertSeedData()
        {
            //Set a local DB context
            context = new DynamoDBContext(client);
            Amazon.DynamoDBv2.DocumentModel.Table MyBookShelfTable = Amazon.DynamoDBv2.DocumentModel.Table.LoadTable(client, tableName);
            ScanFilter scanFilter = new ScanFilter();
            Search search = MyBookShelfTable.Scan(scanFilter);
            //skip to insert seed data if already have some data in the table
            if (search.GetNextSet().Count >0 ) {
                return;
            }

            //Create an MyBookShelf object to save
            List<MyBookShelf> bookShelves = LoadCollectionData();
            foreach (MyBookShelf currentState in bookShelves)
            {
                //Save an MyBookShelf object
                context.Save<MyBookShelf>(currentState);
            }             
        }

        private void RefreshGrid() 
        {
            //Set a local DB context
            context = new DynamoDBContext(client);
            Amazon.DynamoDBv2.DocumentModel.Table MyBookShelfTable = Amazon.DynamoDBv2.DocumentModel.Table.LoadTable(client, tableName);

            ScanFilter scanFilter = new ScanFilter();
            scanFilter.AddCondition("username", ScanOperator.Equal, this.username); // only display the book list of the login user
            Search search = MyBookShelfTable.Scan(scanFilter);
            List<Document> documentList = new List<Document>();
            documentList = search.GetNextSet();

            //dataGridBookList.ItemsSource = documentList;
            List<MyBookShelf> bookShelves = new List<MyBookShelf>();
            foreach (var document in documentList)
            {
                MyBookShelf mybook = new MyBookShelf { 
                    bookId = document["bookId"],
                    username = document["username"],
                    bookTitle = document["bookTitle"],
                    author = document["author"],
                    ISBN = document["ISBN"],
                    pdfPath = document["pdfPath"],
                    lastViewedPage = Int32.Parse(document["lastViewedPage"]),
                    created = DateTime.Parse(document["created"]),
                    updated = DateTime.Parse(document["updated"])

                };
                bookShelves.Add(mybook);
            }
            dataGridBookList.ItemsSource = bookShelves;
           
        }

        private void UpdateBook_Click(object sender, RoutedEventArgs e)
        {
            MyBookShelf myBookShelf = (MyBookShelf)dataGridBookList.SelectedItem;
            if (myBookShelf == null)
            {
                MessageBox.Show("no selelcted book to update. ");
                return;
            }
            MessageBox.Show("current selected book " + myBookShelf.bookTitle);

            bookId = myBookShelf.bookId;

            UpdateBook updateBook = new UpdateBook(this.username, bookId);
            updateBook.Owner = Window.GetWindow(this);
            updateBook.ShowDialog();
            this.RefreshGrid();
        }
    }
}
