﻿using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DataModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Lab02BookReader
{
    /// <summary>
    /// Interaction logic for LastViewedBook.xaml
    /// </summary>
    public partial class LastViewedBook : Window
    {
        string tableName = "MyBookShelf";
        string hashKey = "bookId";
        AmazonDynamoDBClient client;
        DynamoDBContext context;
        private string username;


        public LastViewedBook(String username)
        {
            this.username = username;
            InitializeComponent();
            client = new AmazonDynamoDBClient();
        }
    }
}
